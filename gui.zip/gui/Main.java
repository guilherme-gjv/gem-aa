package gui;

public class Main {
    public static void main(String[] args) {
        Menu menu = new Menu();
        menu.tchau();   // fiz essa função para evitar warning no objeto do Menu :)
    }
}
