public class Main {
  public static void main(String[] args) {
    Executar executar = new Executar();
		executar.greenLine();
  }
}