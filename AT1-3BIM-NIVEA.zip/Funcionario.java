import java.util.Scanner;

public class Funcionario extends Pessoa {
	
	private String setor;
	private float salario;

	private Scanner scanner = new Scanner(System.in);

	Funcionario() {
		super();
		System.out.println("Qual o setor em que o funcionário trabalha? ");
		setor = scanner.nextLine();
		System.out.println("Qual o salário do funcionário em questão? ");
		salario = scanner.nextFloat();
	}

	public void exibirFuncionario() {
		exibirPessoa();
		System.out.println("Setor: "+setor+"\nSalário: "+salario);
	}

	public float getSalario() {
		return salario;
	}
	
}