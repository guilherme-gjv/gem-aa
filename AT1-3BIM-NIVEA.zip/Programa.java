import java.util.Scanner;
import java.util.ArrayList;

public class Programa {
	
	private Scanner scanner = new Scanner(System.in);
	private Scanner sc = new Scanner(System.in);

	ArrayList<Pessoa> clientes = new ArrayList<Pessoa>();
	ArrayList<Gerente> gerentes = new ArrayList<Gerente>();
	ArrayList<Vendedor> vendedores = new ArrayList<Vendedor>();

	public Programa() {
		int opcao = 0;

		do {
			exibirMenu();
			opcao = scanner.nextInt();

			switch(opcao) {

				case 1:
				cadastrarFuncionario();
				break;

				case 2:
				cadastrarCliente();
				break;

				case 3:
				consultarGerentes();
				break;

				case 4:
				consultarVendedores();
				break;

				case 5:
				consultarClientes();
				break;

				case 6:
				valorTotalGerentes();
				break;

				case 7:
				atualizarFuncionario();
				break;

				case 8:
				atualizarVendas();
				break;

			}
		}while(opcao != 9);
	} 

	private void exibirMenu() {
		System.out.println("1 - Cadastrar funcionários \n2 - Cadastrar clientes \n3 - Consultar gerentes \n4 - Consultar vendedores \n5 - Consultar clientes \n6 - Exibir valor total pago pela empresa aos gerentes \n7 - Atualizar endereço e telefone de um determinado funcionário \n8 - Atualizar o valor de vendas de um determinado vendedor \n9 - Sair");
	}

	private void cadastrarFuncionario() {

		System.out.println("Você deseja cadastrar:\n1 - Gerente \n2 - Vendedor");
		int opcao = scanner.nextInt();

		switch(opcao) {

			case 1:
			gerentes.add(new Gerente());
			break;

			case 2:
			vendedores.add(new Vendedor());
			break;

		}
	}

	private void cadastrarCliente() {
		clientes.add(new Pessoa());
	}

	private void consultarGerentes() {
		for(int i = 0; i < gerentes.size(); i++) {
			gerentes.get(i).exibirGerente();
		}
	}

	private void consultarVendedores() {
		for(int i = 0; i < vendedores.size(); i++) {
			vendedores.get(i).exibirVendedor();
		}
	}

	private void consultarClientes() {
		for(int i = 0; i < clientes.size(); i++) {
			clientes.get(i).exibirPessoa();
		}
	}

	private void valorTotalGerentes() {
		float valorTotal = 0;
		for(int i = 0; i < gerentes.size(); i++) {
			valorTotal = valorTotal + gerentes.get(i).valorTotalPago();
		}
		System.out.println("Valor total a ser pago pela empresa para os gerentes: "+valorTotal);
	}

	private void atualizarFuncionario() {
		String nome;
		System.out.println("Atualizar dados de:\n1 - Gerente \n2 - Vendedor");
		int opcao = scanner.nextInt();

		switch(opcao) {

			case 1:
			System.out.println("Digite o nome do gerente: ");
			nome = sc.nextLine();
			for(int i = 0; i < gerentes.size(); i++) {
				if(gerentes.get(i).getNome().equalsIgnoreCase(nome)) {
					System.out.println("Informe o novo telefone: ");
					String telefone = sc.nextLine();
					System.out.println("Informe a nova cidade: ");
					String cidade = sc.nextLine();
					System.out.println("Informe o novo CEP: ");
					String cep = sc.nextLine();
					gerentes.get(i).atualizarTelefoneEndereco(telefone, cidade, cep);
				}
			}
			break;

			case 2: 
			System.out.println("Digite o nome do vendedor: ");
			nome = sc.nextLine();
			for(int i = 0; i < vendedores.size(); i++) {
				if(vendedores.get(i).getNome().equalsIgnoreCase(nome)) {
					System.out.println("Informe o novo telefone: ");
					String telefone = sc.nextLine();
					System.out.println("Informe a nova cidade: ");
					String cidade = sc.nextLine();
					System.out.println("Informe o novo CEP: ");
					String cep = sc.nextLine();
					vendedores.get(i).atualizarTelefoneEndereco(telefone, cidade, cep);
				}
			}
			break;

		}
	}

	private void atualizarVendas() {
		System.out.println("Informe o nome do vendedor para atualizar o valor de vendas: ");
		String nome = sc.nextLine();
		for(int i = 0; i < vendedores.size(); i++) {
			if(vendedores.get(i).getNome().equalsIgnoreCase(nome)) {
				System.out.println("Informe o novo valor de vendas: ");
				float valorVendas = scanner.nextFloat();
				vendedores.get(i).atualizarValorVendas(valorVendas);
			}
		}
	}

}