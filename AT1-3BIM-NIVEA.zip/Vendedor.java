import java.util.Scanner;

public class Vendedor extends Funcionario {

	private float valorVendas;

	private Scanner scanner = new Scanner(System.in);

	public Vendedor() {
		super();
		System.out.println("Qual o valor de vendas do mês do funcionário em questão? ");
		valorVendas = scanner.nextFloat();
	}

	public void exibirVendedor() {
		exibirFuncionario();
		System.out.println("Valor de vendas do mês: "+valorVendas);
	}

	public void atualizarValorVendas(float valorVendas) {
		this.valorVendas = valorVendas;
	}
	
}