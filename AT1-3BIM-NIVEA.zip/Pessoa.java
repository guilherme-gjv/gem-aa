import java.util.Scanner;

public class Pessoa {

	private String nome, telefone, cidade, cep;
	private Scanner scanner = new Scanner(System.in);

	public Pessoa() {
		System.out.println("Digite o nome: ");
		nome = scanner.nextLine();
		System.out.println("Digite o telefone: ");
		telefone = scanner.nextLine();
		System.out.println("Digite a cidade: ");
		cidade = scanner.nextLine();
		System.out.println("Digite o CEP: ");
		cep = scanner.nextLine();
	}

	public void exibirPessoa() {
		System.out.println("Nome: "+nome+"\nTelefone: "+telefone+"\nCidade: "+cidade+"\nCEP: "+cep);
	}

	public String getNome() {
		return nome;
	}

	public void atualizarTelefoneEndereco(String telefone, String cidade, String cep) {
		this.telefone = telefone;
		this.cidade = cidade;
		this.cep = cep;
	}

}