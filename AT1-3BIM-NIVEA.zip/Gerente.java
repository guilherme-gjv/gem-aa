import java.util.Scanner;

public class Gerente extends Funcionario {
	
	private String departamento;
	private float gratificacao;
	
	private Scanner scanner = new Scanner(System.in);

	public Gerente() {
		super();
		System.out.println("Informe o departamento: ");
		departamento = scanner.nextLine();
		System.out.println("Informe a gratificação: ");
		gratificacao = scanner.nextFloat();
	}

	public void exibirGerente() {
		exibirFuncionario();
		System.out.println("Departamento: "+departamento+"\nGratificação recebida: "+gratificacao);		
	}

	public float valorTotalPago() {
		float salarioTotal = gratificacao + getSalario();
		return salarioTotal;
	}
	
}